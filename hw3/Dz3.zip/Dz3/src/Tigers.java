class Tigers extends Cats {
    public int stripeCount; // Кількість смуг
    public int totalAmountOfTigers;
    public Tigers(String name, int age, String furColor, int stripeCount) {
        super(name, age, furColor);
        this.stripeCount = stripeCount;
    }
    public Tigers(String name) {
        super(name);
        this.stripeCount = 90; // Середня кількість смуг
    }
    public Tigers() {
        super();
        this.stripeCount = 100;
    }
    // Гетери
    public int getStripeCount() {
        return stripeCount;
    }
    public int getTotalAmountOfTigers() {
        return totalAmountOfTigers;
    }
    // Сетери
    public void setStripeCount(int stripeCount) {
        this.stripeCount = stripeCount;
    }
    public void voice(){
        System.out.println("Graaaaahrrr");
    }
    public String toString() {
        return "Це тигр. " + super.toString() +
                " Кількість смуг: " + stripeCount + ".";
    }
}
