public class Visitors extends People{
    public boolean left;
    public static int totalAmountOfVisitors = 0;
    //Конструктори
    public Visitors(int age, String name) {
        super(age, name);
        this.left = false;
        totalAmountOfVisitors++;
    }
    public Visitors(int age) {
        super(age);
        this.left = false;
        totalAmountOfVisitors++;
    }
    public Visitors(String name) {
        super(name);
        this.left = false;
        totalAmountOfVisitors++;
    }
    public Visitors(){
        this.left = false;
        totalAmountOfVisitors++;
    }
    //Гетери
    public boolean getLeft() {
        return left;
    }
    public int getTotalAmountOfVisitors() {
        return totalAmountOfVisitors;
    }
    //Сетери
    public void setLeft(boolean left) {
        this.left = left;
    }
    //Дивитись на тварин
    public void seeLion(Lions lion){
        lion.voice();
    }
    public void seeTiger(Tigers tiger){
        tiger.voice();
    }
    public void seeChimpanzee(Chimpanzee chimpanzee){
        chimpanzee.voice();
    }
    public void seeGorilla(Gorillas gorilla){
        gorilla.voice();
    }
    //Покинути зоопарк
    public void leaveZoo(){
        System.out.println("До побачення!!!");
        this.left = true;
    }
    //toString
    public String toString() {
        if (left) {
            return "Вітаю! я " + name + "і мені " + age + "років, і я вже покинув зоопарк";
        } else {
            return "Вітаю! я " + name + "і мені " + age + "років, і я зараз в зоопарку";
        }
    }
}
