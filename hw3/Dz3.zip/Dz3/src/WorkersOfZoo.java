public class WorkersOfZoo extends People{
    public String workPosition;
    public int workHours;
    public static int totalAmountOfWorkers;
    //Конструктори
    public WorkersOfZoo(){
        super();
    }
    public WorkersOfZoo(String workPosition) {
        super();
        this.workPosition = workPosition;
    }
    public WorkersOfZoo(String name, int age, String workPosition) {
        super(age, name);
        this.workPosition = workPosition;
    }
    public WorkersOfZoo(int age, String workPosition) {
        super(age);
        this.workPosition = name;
    }
    public WorkersOfZoo(String name, String workPosition) {
        super(name);
        this.workPosition = workPosition;
    }
    //Гетери
    public String getWorkPosition() {
        return workPosition;
    }
    public int getWorkHours() {
        return workHours;
    }
    public int getTotalAmountOfWorkers() {
        return totalAmountOfWorkers;
    }
    //Сетери
    public void setWorkPosition(String workPosition) {
        this.workPosition = workPosition;
    }
    public void setWorkHours(int workHours) {
        this.workHours = workHours;
    }
    //Методи для годування тварин
    public void feedLion(Lions lion){
        lion.voice();
        workHours++;
    }
    public void feedTiger(Tigers tiger){
        tiger.voice();
        workHours++;
    }
    public void feedChimpanzee(Chimpanzee chimpanzee){
        chimpanzee.voice();
        workHours++;
    }
    public void feedGorilla(Gorillas gorilla){
        gorilla.voice();
        workHours++;
    }
    //Попередити відвідувачів
    public void warnVisitors(){
        System.out.println("В нашому зоопарку відвідувачам заборонено годувати тварин!");
    }
    // Привітати відвідувачів в зоопарку
    public void welcomeVisitor(Visitors visitor){
        System.out.println("Вітаю " + visitor.name +"! Радий бачити вас в нашому зоопарку");
    }
    //Попрощатись з відвідувачем зоопарку
    public void sayGoodbye(Visitors visitor){
        System.out.println("Бувайте " + visitor.name + "! Надіюсь вас знову побачити в нашому зоопарку!");
    }
    //toString
    public String toString(){
        return "Вітаю! я " + name + "і мені " + age + "років, я працюю як" + workPosition;
    }
}
