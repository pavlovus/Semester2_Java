public class People {
    public int age;
    public String name;
    public static int totalAmount = 0;
    //Конструктори
    public People(int age, String name) {
        this.age = age;
        this.name = name;
        totalAmount++;
    }
    public People(String name) {
        this.name = name;
        totalAmount++;
    }
    public People(int age) {
        this.age = age;
        this.name = "Unknown";
        totalAmount++;
    }
    public People() {
        this.name = "Unknown";
        totalAmount++;
    }
    //Гетери
    public int getAge() {
        return age;
    }
    public String getName() {
        return name;
    }
    //Сетери
    public void setAge(int age) {
        this.age = age;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getTotalAmount() {
        return totalAmount;
    }
    //toString
    public String toString() {
        return "Вітаю! я " + name + "і мені " + age + "років";
    }
}
