import java.math.BigInteger;

public class FactorialWithCache {
    private final static int MAXFACTORIAL = 20;
    public static int maxFactorial = 0;
    public static BigInteger[] factorialCache = new BigInteger[21];
    private Factorial factorialCalculator = new Factorial();
    public BigInteger findFactorial(int n) {
        if (n < 0 || n > MAXFACTORIAL) {
            throw new IllegalArgumentException("Число повинно бути від 0 до " + MAXFACTORIAL + "!!!");
        }
        if (maxFactorial == 0) {
            return firstFactorial(n);
        } else if (factorialCache[n] != null){
            return factorialCache[n];
        } else {
            return factorialFromCache(n);
        }
    }

    private BigInteger firstFactorial(int n) {
        for (int i = 0; i <= n; i++) {
            factorialCache[i] = factorialCalculator.factorial(i);
        }
        return factorialCache[n];
    }

    private BigInteger factorialFromCache(int n) {
        for (int i = maxFactorial + 1; i <= n; i++) {
            factorialCache[i] = factorialCache[i - 1].multiply(BigInteger.valueOf(i));
        }
        maxFactorial = n;
        return factorialCache[n];
    }
}

