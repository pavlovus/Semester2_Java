import utils.DataInput;

import java.math.BigInteger;
import java.util.Arrays;

public class FactorialWithCacheUse {
    public static void main(String[] args) {
        FactorialWithCache factorialWithCacheCalculator = new FactorialWithCache();
        while (true){
            int number = DataInput.getInt("Введіть число, щоб знайти його факторіал: ");
            while(number<0 || number>20){
                number = DataInput.getInt("Введіть число ВІД 1 ДО 20: ");
            }
            BigInteger result = factorialWithCacheCalculator.findFactorial(number);
            System.out.println(result);
            System.out.println(Arrays.toString(FactorialWithCache.factorialCache));

            //Запитуємо чи користувач хоче продовжувати
            int choice = DataInput.getInt("Продовжуємо? Введіть 1 для продовження або 0 для виходу: ");
            while(true){
                if(choice == 0){
                    System.out.println("Програма завершена!");
                    return;
                } else if(choice == 1){
                    break;
                } else {
                    choice = DataInput.getInt("Ви ввели інше число!!!. Вам потрібно ввести 1 для продовження або 0 для виходу: ");
                }
            }
        }
    }
}
