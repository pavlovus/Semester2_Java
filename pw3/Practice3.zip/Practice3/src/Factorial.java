import java.math.BigInteger;

public class Factorial {
    public  BigInteger factorial(int number) {
        if (number < 0) {
            throw new IllegalArgumentException("Число повинно бути додатнім!!!");
        }
        BigInteger result = BigInteger.ONE;
        for (int i = 2; i <= number; i++) {
            result = result.multiply(BigInteger.valueOf(i));
        }
        return result;
    }
}
