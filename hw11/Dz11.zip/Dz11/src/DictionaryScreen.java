import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DictionaryScreen extends JFrame {
    public DictionaryScreen(Map<String, HashMap<String, Integer>> dictionary) {
        super("Домашня робота №11");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(650, 650);
        setLocationRelativeTo(null);
        this.setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("Словник термінів і інвертовані списки документів з частотою терміна в документі");
        title.setFont(new Font("Arial", Font.BOLD, 14));

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 16));

        addDictionary(textArea, dictionary);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        JPanel panel = new JPanel(new GridLayout(2, 1, 5, 5));
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.add(title);
        panel.add(titlePanel);
        panel.add(scrollPane);
        add(panel);
    }

    private void addDictionary(JTextArea textArea, Map<String, HashMap<String, Integer>> dictionary) {
        String res = "";
        for(Map.Entry<String, HashMap<String, Integer>> outerEntry : dictionary.entrySet()){
            res += outerEntry.getKey() + " :";
            HashMap<String, Integer> innerMap = outerEntry.getValue();
            for(Map.Entry<String, Integer> innerEntry : innerMap.entrySet()){
                res += innerEntry.getKey() + " - " + innerEntry.getValue() + "; ";
            }
            res += "\n";
        }
        textArea.setText(res);
    }
}
