import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.List;

public class TextFileChooser extends JFrame {

    public TextFileChooser() {
        super("Домашня робота №11");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 200);
        setLocationRelativeTo(null);
        this.setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("Оберіть 10 текстових файлів з мінімальним розміром 150K");

        JButton openButton = new JButton("Обрати файли");
        openButton.setPreferredSize(new Dimension(100, 30));
        openButton.setBorder(null);
        openButton.setFont(new Font("Arial", Font.PLAIN, 12));
        openButton.setForeground(Color.WHITE);
        openButton.setBackground(Color.BLACK);
        openButton.setFocusPainted(false);

        JPanel panel = new JPanel(new GridLayout(2, 1, 5, 5));
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(openButton);
        titlePanel.add(title);
        panel.add(titlePanel);
        panel.add(buttonPanel);
        add(panel);

        openButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showFileChooser();
            }
        });
    }

    private void showFileChooser() {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
                "Only text files (.txt)", "txt");
        chooser.setFileFilter(filter);
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.setMultiSelectionEnabled(true);
        int returnVal = chooser.showOpenDialog(this);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            File[] selectedFiles = chooser.getSelectedFiles();
            if(selectedFiles.length < 10) {
                JOptionPane.showMessageDialog(this, "Вам потрібно обрати 10 файлів!!!", "Помилка!!!", JOptionPane.ERROR_MESSAGE);
            } else if(!checkForSize(selectedFiles)){
                JOptionPane.showMessageDialog(this, "Вам потрібно обрати файли, які будуть більші за 150KB", "Помилка!!!", JOptionPane.ERROR_MESSAGE);
            } else {
                HashMap<String, HashMap<String, Integer>> dictionary = new HashMap<>();
                for(File file : selectedFiles) {
                    analyzeFileForWords(file, dictionary);
                }
                List<Map.Entry<String, HashMap<String, Integer>>> entryList = new ArrayList<>(dictionary.entrySet());
                entryList.sort(Map.Entry.comparingByKey(String.CASE_INSENSITIVE_ORDER));

                Map<String, HashMap<String, Integer>> sortedDictionary = new LinkedHashMap<>();
                for (Map.Entry<String, HashMap<String, Integer>> entry : entryList) {
                    HashMap<String, Integer> innerMap = entry.getValue();
                    List<Map.Entry<String, Integer>> innerList = new ArrayList<>(innerMap.entrySet());
                    innerList.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

                    HashMap<String, Integer> sortedInnerMap = new LinkedHashMap<>();
                    for (Map.Entry<String, Integer> innerEntry : innerList) {
                        sortedInnerMap.put(innerEntry.getKey(), innerEntry.getValue());
                    }

                    sortedDictionary.put(entry.getKey(), sortedInnerMap);
                }
                saveDictionaryOnDisk(sortedDictionary);
                addDictOnScreen(sortedDictionary);
            }
        }
    }

    private void analyzeFileForWords(File file, HashMap<String, HashMap<String, Integer>> dictionary) {
        try{
            FileReader fr = new FileReader(file);
            StreamTokenizer st = new StreamTokenizer(fr);
            st.wordChars('a', 'z');
            st.wordChars('A', 'Z');
            st.wordChars('0', '9');
            st.whitespaceChars(0, ' ');
            st.ordinaryChar(',');
            st.ordinaryChar('.');
            st.ordinaryChar('"');
            st.ordinaryChar('?');
            st.ordinaryChar('!');
            st.ordinaryChar(';');
            st.ordinaryChar(':');
            st.ordinaryChar('/');
            st.ordinaryChar('…');
            while (st.nextToken() != StreamTokenizer.TT_EOF) {
                if ((st.ttype == StreamTokenizer.TT_WORD || st.ttype == StreamTokenizer.TT_NUMBER)) {
                    if(st.sval != null) {
                        HashMap<String, Integer> freqMap = dictionary.get(st.sval);
                        if(freqMap == null) {
                            freqMap = new HashMap<>();
                            freqMap.put(file.getName(), 1);
                            dictionary.put(st.sval, freqMap);
                        } else {
                            Integer freq = freqMap.get(file.getName());
                            freqMap.put(file.getName(), freq == null ? 1 : freq + 1);
                        }
                    }
                }
            }
        }
        catch (FileNotFoundException e){
            System.out.println("Файл не знайдено");
        }
        catch (IOException e){
            System.out.println("Схоже, щось пішло не так");
        }
    }

    private void saveDictionaryOnDisk(Map<String, HashMap<String, Integer>> dictionary) {
        String filePath = "C:\\Users\\Pavlo\\Desktop\\test.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for(Map.Entry<String, HashMap<String, Integer>> outerEntry : dictionary.entrySet()){
                writer.write(outerEntry.getKey());
                writer.newLine();
            }
        } catch (IOException e){
            JOptionPane.showMessageDialog(this, "Схоже, щось пішло не так(((", "Помилка!!!", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addDictOnScreen(Map<String, HashMap<String, Integer>> dictionary) {
        DictionaryScreen resScreen = new DictionaryScreen(dictionary);
        resScreen.setVisible(true);
    }

    private boolean checkForSize(File[] selectedFiles) {
        for(File file : selectedFiles) {
            long fileSize = file.length();
            double fileSizeKB = fileSize / 1024.0;
            if(fileSizeKB < 150){
                return false;
            }
        }
        return true;
    }
}
